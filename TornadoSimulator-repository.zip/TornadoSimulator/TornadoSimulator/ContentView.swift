import SwiftUI

struct Particle {
    var angle: Double
    var radius: Double
    var height: Double
    var speed: Double
    var size: Double
}

struct ContentView: View {
    @State private var particles: [Particle] = []
    @State private var isRunning = true

    private let particleCount = 900

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                Color.black.ignoresSafeArea()

                Canvas { context, size in
                    let center = CGPoint(
                        x: size.width / 2,
                        y: size.height / 2
                    )

                    for particle in particles {
                        let normalizedHeight = particle.height
                        let funnelWidth =
                            20 + normalizedHeight *
                            min(size.width, size.height) * 0.30

                        let r = particle.radius * funnelWidth

                        let point = CGPoint(
                            x: center.x + cos(particle.angle) * r,
                            y: center.y
                                + sin(particle.angle) * r
                                - normalizedHeight * size.height * 0.20
                        )

                        let opacity = 0.15 + normalizedHeight * 0.75
                        let particleSize =
                            particle.size * (0.5 + normalizedHeight)

                        context.fill(
                            Path(
                                ellipseIn: CGRect(
                                    x: point.x - particleSize / 2,
                                    y: point.y - particleSize / 2,
                                    width: particleSize,
                                    height: particleSize
                                )
                            ),
                            with: .color(.white.opacity(opacity))
                        )
                    }
                }

                VStack {
                    Spacer()

                    Button {
                        isRunning.toggle()
                    } label: {
                        Text(isRunning ? "Пауза" : "Запустить")
                            .font(.headline)
                            .foregroundStyle(.white)
                            .padding(.horizontal, 30)
                            .padding(.vertical, 14)
                            .background(.white.opacity(0.15))
                            .clipShape(Capsule())
                    }
                    .padding(.bottom, 30)
                }
            }
            .onAppear {
                createParticles()
            }
            .onReceive(
                Timer.publish(
                    every: 1.0 / 60.0,
                    on: .main,
                    in: .common
                ).autoconnect()
            ) { _ in
                if isRunning {
                    updateParticles()
                }
            }
        }
    }

    private func createParticles() {
        particles = (0..<particleCount).map { _ in
            Particle(
                angle: Double.random(in: 0...(Double.pi * 2)),
                radius: Double.random(in: 0.05...1.0),
                height: Double.random(in: 0...1),
                speed: Double.random(in: 0.015...0.045),
                size: Double.random(in: 1...4)
            )
        }
    }

    private func updateParticles() {
        for i in particles.indices {
            particles[i].angle +=
                particles[i].speed *
                (1.0 + (1.0 - particles[i].radius) * 3.0)

            particles[i].height -= 0.0025

            particles[i].radius -=
                0.0015 *
                (1.0 + (1.0 - particles[i].radius) * 2.0)

            particles[i].angle +=
                sin(particles[i].height * 20) * 0.003

            if particles[i].radius <= 0.02 ||
               particles[i].height <= 0 {
                particles[i] = Particle(
                    angle: Double.random(in: 0...(Double.pi * 2)),
                    radius: Double.random(in: 0.8...1.0),
                    height: 1.0,
                    speed: Double.random(in: 0.015...0.045),
                    size: Double.random(in: 1...4)
                )
            }
        }
    }
}

#Preview {
    ContentView()
}
